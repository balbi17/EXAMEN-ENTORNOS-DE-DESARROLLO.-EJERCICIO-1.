
package EXAMEN;

public interface precioTotal {
    public static void main (String [] args){
        FACTURA f = new FACTURA();
        f.euros(500);
        f.imprimirFactura();
    }
    
    

    
    
}
