
package EXAMEN;

public class PRECIO implements precioTotal {
   int dinero;
   public void euros (int n){
       dinero = n;
   }   
    
    
}
