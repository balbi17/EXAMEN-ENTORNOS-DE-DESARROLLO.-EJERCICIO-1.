
package EXAMEN;

public class FACTURA extends PRECIO {
    public String cliente ="María Ortiz";
    private final String emisor ="Adecco";
    
    public void imprimirFactura (){
        System.out.println("");
        System.out.println("Emisor: " + emisor);
        System.out.println("-----------------------");
        System.out.println("Cliente: " + cliente);
        System.out.println("Precio Total: " + dinero + "€");
    }
        
        
}
